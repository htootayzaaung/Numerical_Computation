_______________
Getting started
_______________


____________________________________________________________________________________________

To avoid the command prompt-> zsh: command not found: conda
			      _____________________________

Make sure that the your terminal profile is -> (base) htootayzaaung@Htoos-MacBook-Air ~ %
						_________________________________________


Instead of -> htootayzaaung@Htoos-MacBook-Air ~ %
	      ___________________________________


To do this type in the terminal window: "source .bash_profile"

____________________________________________________________________________________________



